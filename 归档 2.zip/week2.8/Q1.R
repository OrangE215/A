library(ggplot2)
library(plotly)
# Load the package
library(scatterplot3d)

# Create a grid of values for P(DATA|H1) and P(DATA|H2)
p_data_h1 = seq(0.1, 1, by = 0.1)
p_data_h2 = seq(0.1, 1, by = 0.1)
grid = expand.grid(p_data_h1 = p_data_h1, p_data_h2 = p_data_h2)


# Compute the Bayesian factor for each combination
grid$BF = with(grid, p_data_h1 / p_data_h2)


# Plot the heatmap
ggplot(grid, aes(x = p_data_h1, y = p_data_h2, fill = BF)) +
  geom_tile() +
  scale_fill_gradient(low = "blue", high = "red") +
  labs(x = "P(DATA|H1)", y = "P(DATA|H2)", fill = "BF") +
  theme_minimal()


# Create a 3D scatter plot
scatterplot3d(grid$p_data_h1, grid$p_data_h2, grid$BF, pch = 19, color = "blue", main="3D Scatterplot")
