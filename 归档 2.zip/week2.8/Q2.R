# Number of trials and successes
n_trials <- 20
n_successes <- 7

# Prior probabilities
priors <- rep(1/6, 6)

# Likelihoods
likelihoods <- dbinom(n_successes, size = n_trials, prob = (1:6)/6)

# Unnormalized posteriors
unnormalized_posteriors <- priors * likelihoods

# Normalized posteriors
posteriors <- unnormalized_posteriors / sum(unnormalized_posteriors)

# Print the posteriors
print(posteriors)

# Plot the posteriors
barplot(posteriors, names.arg = 1:6, xlab = "Number on die", ylab = "Posterior probability")
