data = read.csv("drug_trial.csv")
boxplot(data[data$treatment=="placebo",2],
        data[data$treatment=="drugA",2],
        data[data$treatment=="drugB",2])

list_same = c()
list_dif = c()

sample_index[1]
for (i in 1:1000) {
  sample_index <- sample(1:nrow(data),2)
  if (data[sample_index[1],1]==data[sample_index[2],1]) {
    dif = abs(data[sample_index[1],2] - data[sample_index[2],2])
    list_same = c(list_same,dif)
  } 
  if (data[sample_index[1],1]!=data[sample_index[2],1]) {
    dif = abs(data[sample_index[1],2] - data[sample_index[2],2])
    list_dif = c(list_dif,dif)
  } 
}

boxplot(list_same,list_dif)

wilcox.test(list_dif,list_same)
