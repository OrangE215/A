data = read.csv("drug_trial.csv")
model = aov(pain~treatment, data=data)
plot(model)

model = aov(pain~treatment, data=data)
summary(model)
TukeyHSD(model)
