data = read.csv("mouse_experiment.csv")

data1=data[data$diet=="restricted",]
data2=data[data$diet=="unrestricted",]
boxplot(weight_gain ~ genotype, data = data2)
aov1 = aov(weight_gain ~ genotype, data = data2)
plot(aov1)
summary(aov1)
TukeyHSD(aov1)
