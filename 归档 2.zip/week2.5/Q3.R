# 创建数据框
data <- data.frame(
  Season = c("Spring", "Summer", "Fall", "Winter"),
  SevereAllergies = c(5, 1, 1, 9),
  MildAllergies = c(8, 5, 2, 5),
  SporadicAllergies = c(9, 8, 3, 9),
  NeverAllergic = c(18, 16, 12, 5)
)

# 转换数据为矩阵格式
data_matrix <- as.matrix(data[,2:5])

# 创建马赛克图，设置颜色为蓝色和绿色
mosaicplot(t(data_matrix), main = "Mosaicplot of Season and Allergy", xlab = "Season", ylab = "Allergy", col = c("blue", "green", "red","yellow"))

# 执行卡方检验
chisq_result <- chisq.test(data_matrix)

# 显示结果
print(chisq_result)