# 定义观察到的数据
Poll_seasons <- c(Spring = 40, Summer = 30, Autumn = 18, Winter = 28)

# 计算期望的比例
equal_preferences <- sum(Poll_seasons) * 0.25

# 定义人口大小和样本大小
pop_size <- 10000000
sample_size <- 116

# 创建一个大的人口，期望的比例
pop <- rep(names(Poll_seasons), each = pop_size / 4)

# 函数来计算卡方统计量
calc_chi_sq <- function(sample) {
  observed <- table(sample)
  expected <- rep(sample_size / 4, 4)
  chi_sq <- sum((observed - expected)^2 / expected)
  return(chi_sq)
}

# 模拟卡方分布
set.seed(1234) # 为了可重复性
chi_sq_values <- replicate(10000, calc_chi_sq(sample(pop, sample_size)))

# 绘制卡方值的分布
hist(chi_sq_values, freq = FALSE, main="Chi-Square Distribution", xlab="Chi-Square Value")

# 计算观察到的卡方值
obs_chi_sq <- calc_chi_sq(names(Poll_seasons))

# 计算模拟的p值
sim_p_value1 <- mean(chi_sq_values > obs_chi_sq)

# 使用chisq.test()计算p值
test_p_value <- chisq.test(Poll_seasons)$p.value

# 打印结果
print(paste("Simulated p-value:", sim_p_value))
print(paste("Test p-value:", test_p_value))