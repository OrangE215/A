# 输入数据到矩阵中
data_matrix <- matrix(c(7, 2, 3, 7), nrow = 2)
colnames(data_matrix) <- c("WT", "KO")
rownames(data_matrix) <- c("Alive", "Dead")

# 进行卡方检验
chisq_result <- chisq.test(data_matrix, correct = FALSE)
print(chisq_result)

# 开启 Yates's continuity correction
chisq_result_yates <- chisq.test(data_matrix, correct = TRUE)
print(chisq_result_yates)

# 进行 Fisher's exact test
fisher_result <- fisher.test(data_matrix)
print(fisher_result)