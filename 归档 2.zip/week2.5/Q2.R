set.seed(123) # 为了可重复性
df_values <- c(1, 2, 3, 4, 5, 6, 7, 8) # 自由度值

# 创建一个空的数据帧来保存数据
data <- data.frame()

# 对于每一个自由度值，生成随机卡方值并添加到数据帧中
for(df in df_values){
  chi_sq_values <- rchisq(10000, df) # 生成 10000 个随机卡方值
  data_temp <- data.frame(df = df, chi_sq_values = chi_sq_values)
  data <- rbind(data, data_temp) # 将新生成的数据添加到数据帧中
}

# 加载所需的绘图库
library(ggplot2)

# 绘制密度曲线
ggplot(data, aes(x = chi_sq_values, color = as.factor(df))) +
  geom_density() +
  labs(x = "Chi-square values", y = "Density", color = "Degrees of freedom") +
  theme_minimal()