#way1（some wrong）
simulate <- function() {
  state <- 0
  tosses <- 0
  while (state < 4) {
    tosses <- tosses + 1
    coin <- sample(c('H', 'T'), 1)
    if (state == 0) {
      if (coin == 'H') {
        state <- 1
      }
    } else if (state == 1) {
      if (coin == 'T') {
        state <- 2
      } else {
        state <- 0
      }
    } else if (state == 2) {
      if (coin == 'T') {
        state <- 3
      } else {
        state <- 1
      }
    } else if (state == 3) {
      if (coin == 'H') {
        state <- 4
      } else {
        state <- 0
      }
    }
  }
  return(tosses)
}

trials <- replicate(10000, simulate())
cat("Average number of tosses: ", mean(trials))

#way2
# Step 1: Create a function to simulate a coin toss
coin_toss <- function() {
  return(sample(c("H", "T"), 1))
}
# Step 2: Create a function to simulate a sequence of coin tosses until the sequence "H-T-T-H" appears
simulate_sequence <- function() {
  sequence <- c()
  tosses <- 0
  while(TRUE) {
    tosses <- tosses + 1
    sequence <- c(sequence, coin_toss())
    if(length(sequence) >= 4 && all(sequence[(length(sequence)-3):length(sequence)] == c("H", "T", "T", "H"))) {
      break
    }
  }
  return(tosses)
}
# Step 3: Run the simulation multiple times and calculate the average number of tosses required
num_simulations <- 10000
total_tosses <- 0
for(i in 1:num_simulations) {
  total_tosses <- total_tosses + simulate_sequence()
}
average_tosses <- total_tosses / num_simulations

print(paste("On average, it takes", average_tosses, "tosses for the sequence 'H-T-T-H' to appear."))