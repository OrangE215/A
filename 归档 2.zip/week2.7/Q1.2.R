# Probability that an employee is a thief
P_A <- 0.1

# Probability that the lie detector says an employee is lying, given that they are a thief
P_B_given_A <- 0.8

# Total probability that the lie detector says an employee is lying
P_B <- 0.08 + 0.18

# Use Bayes' theorem to find the probability that an employee is a thief, given that the lie detector says they are lying
P_A_given_B <- (P_B_given_A * P_A) / P_B

# Multiply by the number of people the lie detector identified as liars to find the expected number of these who are thieves
thieves <- P_A_given_B * 50

print(thieves)