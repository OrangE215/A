# 画次数与到达最终状态的关系
# 定义转移矩阵
transition_matrix <- matrix(c(0.5,0.5,0,0,0,
                              0,0.5,0.5,0,0,
                              0,0.5,0,0.5,0,
                              0.5,0,0,0,0.5,
                              0,0,0,0,1),
                            nrow=5, ncol=5, byrow = TRUE)

# 定义初始状态
state <- 1

# 定义投掷次数
n_tosses <- 1000

# 初始化状态记录向量
state_record <- numeric(n_tosses)

# 初始化到达吸收状态的记录向量
reached_absorbing_state <- logical(n_tosses)

# 模拟投掷
set.seed(123)
for (i in 1:n_tosses) {
  # 记录当前状态
  state_record[i] <- state
  
  # 判断下一个状态
  state <- sample(1:5, size = 1, prob = transition_matrix[state, ])
  
  # 如果已经到达吸收状态，则记录
  if (state == 5) {
    reached_absorbing_state[i:n_tosses] <- TRUE
    break
  }
}

# 计算每次投掷后到达吸收状态的累积概率
cumulative_prob_absorbing <- cumsum(reached_absorbing_state) / 1:n_tosses

# 绘制图形
plot(cumulative_prob_absorbing, type = "l", xlab = "Number of Tosses", 
     ylab = "Cumulative Probability of Absorbing State", 
     main = "Cumulative Probability of Reaching Absorbing State Over Time")




#通过模拟获得平均步数
# Define the transition matrix
transition_matrix <- matrix(c(0.5, 0.5, 0, 0, 0,
                              0, 0.5, 0.5, 0, 0,
                              0, 0.5, 0, 0.5, 0,
                              0.5, 0, 0, 0, 0.5,
                              0, 0, 0, 0, 1), 
                            nrow=5, byrow=TRUE)

# Define the simulation function
simulate <- function() {
  state <- 1
  steps <- 0
  while (state != 5) {
    steps <- steps + 1
    state <- sample(1:5, 1, prob=transition_matrix[state,])
  }
  return(steps)
}

# Run the simulation multiple times and calculate the average number of steps
num_simulations <- 10000
total_steps <- 0
for(i in 1:num_simulations) {
  total_steps <- total_steps + simulate()
}
average_steps <- total_steps / num_simulations

print(paste("On average, it takes", average_steps, "steps to reach state 4."))



# 计算平均步数
# 定义转移矩阵
transition_matrix <- matrix(c(0.5, 0.5, 0, 0, 0,
                              0, 0.5, 0.5, 0, 0,
                              0, 0.5, 0, 0.5, 0,
                              0.5, 0, 0, 0, 0.5,
                              0, 0, 0, 0, 1),
                            nrow=5, ncol=5, byrow = TRUE)

# 定义Q和I
Q <- transition_matrix[1:4, 1:4]
I <- diag(4)

# 计算N
N <- solve(I - Q)

# 计算每个非吸收状态到达吸收状态的平均步数
average_steps_to_absorption <- rowSums(N)

# 输出从状态1开始到达吸收状态的平均步数
average_steps_from_state1_to_absorption <- average_steps_to_absorption[1]
print(average_steps_to_absorption)
