# Number of employees
n <- 1000
# Generate a vector of employees, where 1 represents a thief and 0 represents an honest employee
employees <- c(rep(1, n*0.1), rep(0, n*0.9))
# Shuffle the employees
employees <- sample(employees)
# Generate a vector of lie detector results, where 1 represents a lie and 0 represents truth
# The lie detector is 80% accurate, so for thieves (employees == 1), it correctly identifies them as liars 80% of the time,
# and for honest employees (employees == 0), it incorrectly identifies them as liars 20% of the time
results <- ifelse(employees == 1, rbinom(n, 1, 0.8), rbinom(n, 1, 0.2))
# Find the number of people who the lie detector identified as liars
liars <- which(results == 1)
# Find the number of these who are actually thieves
thieves <- sum(employees[liars])
print(thieves)
prob = thieves/length(liars)
print(prob*50)
