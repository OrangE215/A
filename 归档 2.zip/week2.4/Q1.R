# 1
count = 0
for (i in 1:100000) {
  sample = rnorm(10, 178, 10)
  t = t.test(sample, mu = 175)
  if (t$p.value <= 0.05){
    count = count + 1
  }
}

power = count / 100000

# 2 cheating way
mu0 <- 175  
mu1 <- 178  
sigma <- 10  
delta <- abs(mu1 - mu0) 
sample_sizes <- seq(5, 100, by = 5)

power_list = c()
for (i in sample_sizes){
  result <- power.t.test(n = i, delta = delta, sd = 10, sig.level = 0.05, type = "one.sample", alternative = "two.sided")
  power_list = c(power_list, result$power)
}

plot(sample_sizes , power_list)= count/100000
print(power)


