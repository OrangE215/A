# 1
count1 = 0
for (i in 1:100000) {
  sample1 = rnorm(10, 130, 30)
  sample2 = rnorm(10, 117, 27)
  t1 = t.test(sample1, sample2,alternative = "greater")
  if (t1$p.value <= 0.05 ){
    count1 = count1 + 1
  }
}

power1 = count1 / 100000

# 2 

delta <- 130 * 0.1
sd <- 30
power <- 0.8
sig.level <- 0.05
result <- power.t.test(delta = delta, sd = sd, sig.level = sig.level, power = power, type = "two.sample", alternative = "one.sided")
result$n

# 3
delta <- 13
sd <- 30
power <- 0.8
sig.level <- 0.05
result <- power.t.test(delta = delta, sd = sd, sig.level = sig.level, power = power, type = "paired", alternative = "one.sided")
result$n

# 4
sig.levels <- seq(0.01, 0.05, by = 0.01)
a = c()
for (i in sig.levels){
  result <- power.t.test(delta = delta, sd = sd, sig.level = sig.level, power = power, type = "one.sample", alternative = "one.sided")
}